import { useState, useCallback, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../../home/components/Navbar';

type UploadType = 'file' | 'folder' | 'url';

interface UploadedFile {
  id: number;
  name: string;
  size: string;
  type: string;
  status: 'uploading' | 'success' | 'error';
  progress: number;
}

interface Experiment {
  id: string;
  name: string;
  year: string;
  location: string;
  type: string;
  materialCount: number;
  status: 'active' | 'inactive';
  hasPermission: boolean;
}

// Mock Data
const MOCK_EXPERIMENTS: Experiment[] = [
  { id: '1', name: '2024年 杨凌 DUS 表型试验', year: '2024', location: '杨凌', type: '表型', materialCount: 120, status: 'active', hasPermission: true },
  { id: '2', name: '2024年 海南 玉米育种试验', year: '2024', location: '海南', type: '基因型', materialCount: 500, status: 'active', hasPermission: true },
  { id: '3', name: '2023年 环境监测项目', year: '2023', location: '杨凌', type: '环境', materialCount: 0, status: 'active', hasPermission: true },
  { id: '4', name: '2023年 小麦抗病试验', year: '2023', location: '杨凌', type: '表型', materialCount: 80, status: 'inactive', hasPermission: true },
  { id: '5', name: '机密育种项目', year: '2024', location: '未知', type: '基因型', materialCount: 0, status: 'active', hasPermission: false },
];

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
};

export default function NewTaskPage() {
  const navigate = useNavigate();
  const [uploadType, setUploadType] = useState<UploadType>('file');
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [urlInput, setUrlInput] = useState('');
  const [taskName, setTaskName] = useState('');
  const [dataType, setDataType] = useState('表型');
  const [dataset, setDataset] = useState(''); // Stores experiment ID
  const [remarks, setRemarks] = useState('');

  // Experiment Select State
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedExperiment, setSelectedExperiment] = useState<Experiment | null>(null);
  const [typeMismatchWarning, setTypeMismatchWarning] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Mock User Role
  const isAdmin = true; // Toggle this to test permission logic

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Filter experiments
  const filteredExperiments = MOCK_EXPERIMENTS.filter(exp => 
    exp.status === 'active' && 
    exp.hasPermission &&
    (exp.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
     exp.year.includes(searchTerm) || 
     exp.location.includes(searchTerm))
  );

  const handleExperimentSelect = (exp: Experiment) => {
    setDataset(exp.id);
    setSelectedExperiment(exp);
    setSearchTerm(exp.name); // Set input to name
    setIsDropdownOpen(false);
    
    // Validate type
    if (exp.type !== dataType) {
      setTypeMismatchWarning(`当前试验类型为「${exp.type}」，不支持${dataType}数据上传`);
    } else {
      setTypeMismatchWarning('');
    }
  };

  const handleDataTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newType = e.target.value;
    setDataType(newType);
    
    // Re-validate if experiment is selected
    if (selectedExperiment && selectedExperiment.type !== newType) {
      setTypeMismatchWarning(`当前试验类型为「${selectedExperiment.type}」，不支持${newType}数据上传`);
    } else {
      setTypeMismatchWarning('');
    }
  };

  const handleCreateExperiment = () => {
    if (!isAdmin) {
      alert('您没有权限新建试验，请联系管理员。');
      return;
    }
    // Navigate to create experiment page
    navigate('/experiments/new');
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const simulateUpload = useCallback((fileId: number) => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 30;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        setUploadedFiles(prev => 
          prev.map(f => f.id === fileId ? { ...f, status: 'success', progress: 100 } : f)
        );
      } else {
        setUploadedFiles(prev => 
          prev.map(f => f.id === fileId ? { ...f, progress: Math.floor(progress) } : f)
        );
      }
    }, 500);
  }, []);

  const handleFiles = useCallback((files: File[]) => {
    const newFiles: UploadedFile[] = files.map((file, index) => ({
      id: Date.now() + index,
      name: file.name,
      size: formatFileSize(file.size),
      type: file.type || '未知类型',
      status: 'uploading',
      progress: 0
    }));

    setUploadedFiles(prev => [...prev, ...newFiles]);
    // Auto-fill task name if empty
    if (!taskName && files.length > 0) {
        const name = files[0].name.split('.')[0];
        setTaskName(`${name}_导入任务`);
    }

    newFiles.forEach(file => {
      simulateUpload(file.id);
    });
  }, [simulateUpload, taskName]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, [handleFiles]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFiles(files);
    }
  }, [handleFiles]);

  const handleSubmit = () => {
    // In a real app, this would create the task via API
    // For now, navigate back to task list
    navigate('/tasks');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      
      <main className="flex-grow max-w-[1600px] w-full mx-auto px-6 py-8 pt-24">
        <div className="mb-8 flex items-center gap-4">
          <button 
            onClick={() => navigate('/tasks')}
            className="text-gray-500 hover:text-gray-700 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <i className="ri-arrow-left-line text-2xl"></i>
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">新建上传任务</h1>
            <p className="text-sm text-gray-500 mt-1">上传数据文件并配置关联试验信息</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
            {/* 任务基本信息 */}
            <div className="grid grid-cols-2 gap-6 mb-8">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">任务名称</label>
                    <input 
                        type="text" 
                        value={taskName}
                        onChange={(e) => setTaskName(e.target.value)}
                        placeholder="请输入任务名称"
                        className="w-full border-gray-300 rounded-lg px-4 py-2 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">数据类型</label>
                    <select 
                        value={dataType}
                        onChange={handleDataTypeChange}
                        className="w-full border-gray-300 rounded-lg px-4 py-2 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                    >
                        <option value="基因型">基因型</option>
                        <option value="表型">表型</option>
                        <option value="环境">环境</option>
                    </select>
                </div>
                <div className="relative" ref={dropdownRef}>
                    <label className="block text-sm font-medium text-gray-700 mb-2">所属数据集 / 试验</label>
                    <div 
                      className="relative"
                      onClick={() => setIsDropdownOpen(true)}
                    >
                      <input 
                          type="text" 
                          value={searchTerm}
                          onChange={(e) => {
                            setSearchTerm(e.target.value);
                            setIsDropdownOpen(true);
                            if (!e.target.value) {
                              setDataset('');
                              setSelectedExperiment(null);
                              setTypeMismatchWarning('');
                            }
                          }}
                          placeholder="搜索或选择试验..."
                          className={`w-full border rounded-lg px-4 py-2 pr-10 shadow-sm focus:ring-teal-500 focus:border-teal-500 ${typeMismatchWarning ? 'border-red-300 focus:ring-red-200' : 'border-gray-300'}`}
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-gray-400">
                        <i className="ri-arrow-down-s-line"></i>
                      </div>
                    </div>
                    
                    {/* Warning Message */}
                    {typeMismatchWarning && (
                      <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                        <i className="ri-error-warning-line"></i>
                        {typeMismatchWarning}
                      </p>
                    )}

                    {/* Dropdown Menu */}
                    {isDropdownOpen && (
                      <div className="absolute z-10 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-80 overflow-y-auto">
                        {filteredExperiments.length > 0 ? (
                          <div className="py-1">
                            {filteredExperiments.map((exp) => (
                              <button
                                key={exp.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleExperimentSelect(exp);
                                }}
                                className="w-full text-left px-4 py-2 hover:bg-teal-50 transition-colors border-b border-gray-50 last:border-0"
                              >
                                <div className="font-medium text-gray-900">{exp.name}</div>
                                <div className="text-xs text-gray-500 mt-0.5">
                                  类型：{exp.type} ｜ 材料数：{exp.materialCount} ｜ {exp.location}
                                </div>
                              </button>
                            ))}
                          </div>
                        ) : (
                          <div className="px-4 py-3 text-sm text-gray-500 text-center">
                            未找到相关试验
                          </div>
                        )}
                        
                        {/* Create New Action */}
                        <div className="border-t border-gray-100 p-2 bg-gray-50 sticky bottom-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCreateExperiment();
                            }}
                            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-teal-600 bg-white border border-teal-200 rounded-md hover:bg-teal-50 transition-colors"
                          >
                            <i className="ri-add-line"></i>
                            新建试验
                          </button>
                        </div>
                      </div>
                    )}
                </div>
            </div>

          {/* 上传区域 */}
          <div 
            className={`
              relative border-2 border-dashed rounded-xl p-12 text-center transition-all
              ${dragActive ? 'border-teal-500 bg-teal-50' : 'border-gray-300 hover:border-teal-400 hover:bg-gray-50'}
            `}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <input 
              type="file" 
              className="hidden" 
              id="file-upload"
              multiple 
              onChange={handleFileInput}
            />
            
            <div className="w-16 h-16 bg-teal-100 text-teal-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-upload-cloud-2-line text-3xl"></i>
            </div>
            
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              点击或拖拽文件到此处
            </h3>
            <p className="text-gray-500 text-sm mb-6">
              支持 Excel, CSV, PDF 等格式文件
            </p>
            
            <label 
              htmlFor="file-upload"
              className="px-6 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors cursor-pointer inline-flex items-center gap-2"
            >
              <i className="ri-folder-open-line"></i>
              选择文件
            </label>
          </div>

          {/* 文件列表 */}
          {uploadedFiles.length > 0 && (
            <div className="mt-8 space-y-4">
              <h4 className="font-medium text-gray-900">已添加文件</h4>
              {uploadedFiles.map(file => (
                <div key={file.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg border border-gray-100">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center border border-gray-200 text-teal-600">
                    <i className="ri-file-text-line text-xl"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between mb-1">
                      <span className="font-medium text-gray-900 truncate">{file.name}</span>
                      <span className="text-xs text-gray-500">{file.size}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div 
                        className={`h-1.5 rounded-full transition-all duration-300 ${
                          file.status === 'error' ? 'bg-red-500' : 'bg-teal-500'
                        }`}
                        style={{ width: `${file.progress}%` }}
                      ></div>
                    </div>
                  </div>
                  {file.status === 'success' && (
                    <i className="ri-checkbox-circle-fill text-teal-500 text-xl"></i>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* 备注 */}
          <div className="mt-8">
            <label className="block text-sm font-medium text-gray-700 mb-2">备注</label>
            <textarea 
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="请输入任务备注信息"
              rows={3}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            ></textarea>
          </div>

          {/* 提交按钮 */}
            <div className="mt-8 pt-8 border-t border-gray-100 flex justify-end gap-4">
                <button 
                    onClick={() => navigate('/tasks')}
                    className="px-6 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                    取消
                </button>
                <button 
                    onClick={handleSubmit}
                    disabled={uploadedFiles.length === 0}
                    className={`
                        px-6 py-2.5 rounded-lg text-white font-medium flex items-center gap-2
                        ${uploadedFiles.length === 0 ? 'bg-gray-300 cursor-not-allowed' : 'bg-teal-600 hover:bg-teal-700 shadow-lg shadow-teal-600/20'}
                    `}
                >
                    <i className="ri-check-line"></i>
                    创建任务
                </button>
            </div>
        </div>
      </main>
    </div>
  );
}