import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Navbar from '../../home/components/Navbar';

export default function NewExperimentPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditMode = !!id;

  const [formData, setFormData] = useState({
    name: '',
    year: new Date().getFullYear().toString(),
    location: '',
    type: 'phenotype',
    description: '',
    // Advanced
    designType: 'RCBD',
    replications: 3,
    remarks: ''
  });

  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    if (isEditMode) {
      // Mock fetch data
      setFormData({
        name: '2024年度玉米抗旱试验',
        year: '2024',
        location: '杨凌',
        type: 'phenotype',
        description: '测试不同玉米品种在干旱条件下的生长表现',
        designType: 'RCBD',
        replications: 3,
        remarks: '无'
      });
    }
  }, [isEditMode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock save
    const datasetId = isEditMode ? id : `EXP-${formData.year}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
    console.log('Saving experiment:', { ...formData, id: datasetId });
    alert(`试验已保存！ID: ${datasetId}`);
    navigate('/experiments');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      
      <main className="flex-grow max-w-[1600px] w-full mx-auto px-6 py-8 pt-24">
        <div className="mb-8 flex items-center gap-4">
          <button 
            onClick={() => navigate('/experiments')}
            className="text-gray-500 hover:text-gray-700 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <i className="ri-arrow-left-line text-2xl"></i>
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {isEditMode ? '编辑试验' : '新建试验'}
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              {isEditMode ? `编辑 ID: ${id} 的试验信息` : '创建新的田间试验或测序批次记录'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          {/* Basic Info */}
          <div className="p-6 space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">基本信息</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <span className="text-red-500 mr-1">*</span>试验名称
                </label>
                <input 
                  type="text" 
                  required
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="请输入试验名称"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <span className="text-red-500 mr-1">*</span>年份
                </label>
                <select 
                  required
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                  value={formData.year}
                  onChange={(e) => setFormData({...formData, year: e.target.value})}
                >
                  <option value="2025">2025</option>
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <span className="text-red-500 mr-1">*</span>地点
                </label>
                <input 
                  type="text" 
                  required
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  placeholder="请输入地点"
                />
              </div>

              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">试验类型</label>
                <div className="flex gap-4">
                  {[
                    { value: 'phenotype', label: '表型试验' },
                    { value: 'environment', label: '环境试验' },
                    { value: 'combined', label: '综合试验' }
                  ].map((type) => (
                    <label key={type.value} className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="type"
                        value={type.value}
                        checked={formData.type === type.value}
                        onChange={(e) => setFormData({...formData, type: e.target.value as any})}
                        className="text-teal-600 focus:ring-teal-500"
                      />
                      <span className="text-gray-700">{type.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">描述</label>
                <textarea 
                  rows={3}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="请输入试验描述"
                />
              </div>
            </div>
          </div>

          {/* Advanced Info */}
          <div className="border-t border-gray-100">
            <button 
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="w-full px-6 py-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
            >
              <span className="font-semibold text-gray-900">高级信息</span>
              <i className={`ri-arrow-down-s-line text-lg transition-transform ${showAdvanced ? 'rotate-180' : ''}`}></i>
            </button>
            
            {showAdvanced && (
              <div className="p-6 space-y-6 bg-gray-50/30">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">设计类型</label>
                    <select 
                      className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                      value={formData.designType}
                      onChange={(e) => setFormData({...formData, designType: e.target.value})}
                    >
                      <option value="RCBD">RCBD (随机区组)</option>
                      <option value="SplitPlot">裂区设计</option>
                      <option value="Augmented">增广设计</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">重复次数</label>
                    <input 
                      type="number" 
                      min="1"
                      className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                      value={formData.replications}
                      onChange={(e) => setFormData({...formData, replications: parseInt(e.target.value)})}
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">备注</label>
                    <input 
                      type="text" 
                      className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                      value={formData.remarks}
                      onChange={(e) => setFormData({...formData, remarks: e.target.value})}
                      placeholder="其他备注信息"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end gap-3">
            <button 
              type="button"
              onClick={() => navigate('/experiments')}
              className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 font-medium transition-colors"
            >
              取消
            </button>
            <button 
              type="submit"
              className="px-6 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 font-medium shadow-sm transition-colors"
            >
              保存
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
