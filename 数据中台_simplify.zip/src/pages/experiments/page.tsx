import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../home/components/Navbar';

interface Experiment {
  id: string;
  name: string;
  year: string;
  location: string;
  type: 'phenotype' | 'environment';
  taskCount: number;
  status: 'active' | 'inactive';
}

export default function ExperimentListPage() {
  const navigate = useNavigate();
  const [filterName, setFilterName] = useState('');
  const [filterYear, setFilterYear] = useState('');
  const [filterLocation, setFilterLocation] = useState('');

  // Mock data
  const experiments: Experiment[] = [
    { id: 'EXP-2024-001', name: '2024年度玉米抗旱试验', year: '2024', location: '杨凌', type: 'phenotype', taskCount: 5, status: 'active' },
    { id: 'EXP-2024-002', name: '2024年度土壤温湿度监测', year: '2024', location: '杨凌', type: 'environment', taskCount: 12, status: 'active' },
    { id: 'EXP-2023-001', name: '2023年度玉米产量测试', year: '2023', location: '海南', type: 'phenotype', taskCount: 8, status: 'inactive' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      
      <main className="flex-grow max-w-[1600px] w-full mx-auto px-6 py-8 pt-24">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">数据集 / 试验管理</h1>
            <p className="text-sm text-gray-500 mt-1">管理所有田间试验、测序批次及相关元数据</p>
          </div>
          <button 
            onClick={() => navigate('/experiments/new')}
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 font-medium transition-colors shadow-sm"
          >
            <i className="ri-add-line text-lg"></i>
            新建试验
          </button>
        </div>

        {/* Filter Section */}
        <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 mb-6 flex flex-wrap gap-4 items-end">
          <div className="flex-1 min-w-[240px]">
            <label className="block text-sm font-medium text-gray-700 mb-1">试验名称</label>
            <div className="relative">
                <input 
                  type="text" 
                  placeholder="请输入试验名称"
                  className="w-full pl-10 pr-4 rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 text-sm"
                  value={filterName}
                  onChange={(e) => setFilterName(e.target.value)}
                />
                <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          <div className="w-40">
            <label className="block text-sm font-medium text-gray-700 mb-1">年份</label>
            <select 
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 text-sm"
              value={filterYear}
              onChange={(e) => setFilterYear(e.target.value)}
            >
              <option value="">全部年份</option>
              <option value="2025">2025</option>
              <option value="2024">2024</option>
              <option value="2023">2023</option>
            </select>
          </div>
          <div className="w-40">
            <label className="block text-sm font-medium text-gray-700 mb-1">地点</label>
            <select 
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 text-sm"
              value={filterLocation}
              onChange={(e) => setFilterLocation(e.target.value)}
            >
              <option value="">全部地点</option>
              <option value="杨凌">杨凌</option>
              <option value="海南">海南</option>
              <option value="北京">北京</option>
            </select>
          </div>
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-medium transition-colors">
            重置
          </button>
          <button className="px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 font-medium transition-colors shadow-sm">
            查询
          </button>
        </div>

        {/* List Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">试验名称</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">年份</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">地点</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">数据类型</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">关联任务数</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">状态</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {experiments.map((exp) => (
                <tr key={exp.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button 
                      onClick={() => navigate(`/experiments/${exp.id}/edit`)}
                      className="text-teal-600 hover:text-teal-800 font-medium"
                    >
                      {exp.name}
                    </button>
                    <div className="text-xs text-gray-400 mt-0.5">{exp.id}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{exp.year}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{exp.location}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      exp.type === 'phenotype' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {exp.type === 'phenotype' ? '表型' : '环境'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{exp.taskCount}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      exp.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${
                        exp.status === 'active' ? 'bg-green-600' : 'bg-gray-500'
                      }`}></span>
                      {exp.status === 'active' ? '启用' : '停用'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button 
                      onClick={() => navigate(`/experiments/${exp.id}/edit`)}
                      className="text-teal-600 hover:text-teal-900 mr-4"
                    >
                      编辑
                    </button>
                    <button className="text-gray-400 hover:text-gray-600">
                      查看
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
