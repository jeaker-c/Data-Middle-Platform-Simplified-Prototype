import { useState } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import StatsOverview from './components/StatsOverview';
import DataPreview from './components/DataPreview';
import DataUpload from './components/DataUpload';
import FileTools from './components/FileTools';
import Footer from './components/Footer';

export default function HomePage() {
  const [activeSection, setActiveSection] = useState('overview');

  return (
    <div className="min-h-screen bg-gray-50" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar activeSection={activeSection} setActiveSection={setActiveSection} />
      <HeroSection />
      <StatsOverview />
      <DataPreview />
      <DataUpload />
      <FileTools />
      <Footer />
    </div>
  );
}
