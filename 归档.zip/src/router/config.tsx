import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import Settings from "../pages/settings/page";
import OverviewPage from "../pages/overview/page";
import UploadPage from "../pages/upload/page";
import DataQueryPage from "../pages/data-query/page";
import ToolsPage from "../pages/tools/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/overview",
    element: <OverviewPage />,
  },
  {
    path: "/upload",
    element: <UploadPage />,
  },
  {
    path: "/data-query",
    element: <DataQueryPage />,
  },
  {
    path: "/tools",
    element: <ToolsPage />,
  },
  {
    path: "/settings",
    element: <Settings />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;
